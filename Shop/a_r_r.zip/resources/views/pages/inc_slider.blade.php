<section class="banner-main mt-20">
            <div class="banner">
              <div class="main-banner">
                <!--<div class="banner-1"> <img src="images/banner3.jpg" alt="Stylexpo">-->
                  
                <!--</div>-->
                <div class="banner-2"> <img src="images/banner2.jpg" alt="Stylexpo">
                 
                </div>
                <div class="banner-3"> <img src="images/banner1.jpg" alt="Stylexpo">
                  
                </div>
              </div>
            </div>
          </section>