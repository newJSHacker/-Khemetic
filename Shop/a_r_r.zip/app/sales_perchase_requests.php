<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class sales_perchase_requests extends Model
{
    //
}
