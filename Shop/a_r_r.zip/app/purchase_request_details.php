<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class purchase_request_details extends Model
{

}
