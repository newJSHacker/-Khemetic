<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class measurments_males extends Model
{
    //
}
