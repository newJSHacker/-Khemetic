<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class quotation extends Model
{
    //
}
