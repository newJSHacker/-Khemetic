<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class purchase_reques extends Model
{
    //
}
