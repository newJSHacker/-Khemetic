<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class qoutation_details extends Model
{
    //
}
