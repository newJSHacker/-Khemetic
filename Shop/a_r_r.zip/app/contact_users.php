<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class contact_users extends Model
{
    //
}
